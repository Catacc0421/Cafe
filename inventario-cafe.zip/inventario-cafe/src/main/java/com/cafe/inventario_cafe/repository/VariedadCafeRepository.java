package com.cafe.inventario_cafe.repository;

import com.cafe.inventario_cafe.entity.VariedadCafe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VariedadCafeRepository extends JpaRepository<VariedadCafe, Long> {
}
