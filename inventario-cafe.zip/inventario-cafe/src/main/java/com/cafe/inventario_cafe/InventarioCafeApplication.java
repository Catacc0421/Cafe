package com.cafe.inventario_cafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioCafeApplication.class, args);
	}

}
