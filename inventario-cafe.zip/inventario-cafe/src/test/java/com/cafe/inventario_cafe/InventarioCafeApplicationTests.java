package com.cafe.inventario_cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
